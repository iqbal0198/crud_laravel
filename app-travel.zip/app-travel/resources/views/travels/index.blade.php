@extends('travels.layout')
@section('content')

<div class="container">
<a class='btn btn-primary' href="{{ route('travels.create') }}">Add New</a><br><br>

<table class="table table-bordered">
<tr class="table-dark text-center">
<th>Id</th>
<th>Nama</th>
<th>Gambar</th>
<th>Kota</th>
<th>Harga Tiket</th>
<th>Aksi</th>
</tr>

@foreach($travels as $travels)

<tr>
<td>{{ $travels->id }}</td>
<td>{{ $travels->nama }}</td>
<td>{{ $travels->gambar }}</td>
<td>{{ $travels->kota }}</td>
<td>{{ $travels->harga_tiket }}</td>
<td class="text-center">

    <a class='btn btn-success' href="{{ route('travels.show',$travels->id) }}">Show</a>
    <a class='btn btn-warning' href="{{ route('travels.edit',$travels->id) }}">Edit</a>
    
    <form onclick="return confirm('Are you sure ?')" action="{{ route('travels.destroy',$travels->id) }}" method="post" style="display:inline;">
    @csrf
    @method('DELETE')
    <button class="btn btn-danger">Delete</button>
    </form>
    </td>
    </tr>

@endforeach

</table>

</div>



@endsection

