@extends('travels.layout')

@section('content')

<form class="form" action="{{ route('travels.update', $travel->id) }}" method="post">
@csrf
@method('PUT')

<label for="">Nama</label><br>
<input type="text" name="nama" class="form-control" value="{{ $travel->nama }}"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" class="form-control" value="{{ $travel->kota }}"><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" class="form-control" value="{{ $travel->harga_tiket }}"><br><br>

<label for="">Gambar</label><br>
<input type="file" name="gambar"  value="{{ $travel->gambar }}"><br><br>

<input type="submit" value="Save" class="btn btn-primary">
</form>

@endsection