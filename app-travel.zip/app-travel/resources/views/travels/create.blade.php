@extends('travels.layout')

@section('content')

<form class="form" action="{{ route('travels.store') }}" method="post">
@csrf

<label for="">Nama</label><br>
<input type="text" name="nama" class="form-control"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" class="form-control"><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" class="form-control"><br><br>

<label for="">Gambar</label><br>
<input type="file" name="gambar"><br><br>


<input type="submit" value="Save" class="btn btn-primary">
</form>

@endsection