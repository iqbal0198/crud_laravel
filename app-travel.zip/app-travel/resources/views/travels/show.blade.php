@extends('travels.layout')

@section('content')
<h3>{{ $travel->title }}</h3>

<p> Atas Nama : {{ $travel->nama }}</p>
<p> Tujuan : {{ $travel->kota }}</p>
<p> Harga Tiket : {{ $travel->harga_tiket }}</p>
@endsection