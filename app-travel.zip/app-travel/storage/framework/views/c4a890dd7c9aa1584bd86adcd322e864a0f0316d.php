<?php $__env->startSection('content'); ?>

<div class="container">
<a class='btn btn-primary' href="<?php echo e(route('travels.create')); ?>">Add New</a><br><br>

<table class="table table-bordered">
<tr class="table-dark text-center">
<th>Id</th>
<th>Nama</th>
<th>Gambar</th>
<th>Kota</th>
<th>Harga Tiket</th>
<th>Aksi</th>
</tr>

<?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td><?php echo e($travels->id); ?></td>
<td><?php echo e($travels->nama); ?></td>
<td><?php echo e($travels->gambar); ?></td>
<td><?php echo e($travels->kota); ?></td>
<td><?php echo e($travels->harga_tiket); ?></td>
<td class="text-center">

    <a class='btn btn-success' href="<?php echo e(route('travels.show',$travels->id)); ?>">Show</a>
    <a class='btn btn-warning' href="<?php echo e(route('travels.edit',$travels->id)); ?>">Edit</a>
    
    <form onclick="return confirm('Are you sure ?')" action="<?php echo e(route('travels.destroy',$travels->id)); ?>" method="post" style="display:inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button class="btn btn-danger">Delete</button>
    </form>
    </td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-travel/resources/views/travels/index.blade.php ENDPATH**/ ?>