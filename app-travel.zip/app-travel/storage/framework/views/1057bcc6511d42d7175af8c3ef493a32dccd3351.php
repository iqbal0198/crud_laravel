<?php $__env->startSection('content'); ?>

<form class="form" action="<?php echo e(route('travels.update', $travel->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<label for="">Nama</label><br>
<input type="text" name="nama" class="form-control" value="<?php echo e($travel->nama); ?>"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" class="form-control" value="<?php echo e($travel->kota); ?>"><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" class="form-control" value="<?php echo e($travel->harga_tiket); ?>"><br><br>


<input type="submit" value="Save" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-travel/resources/views/travels/edit.blade.php ENDPATH**/ ?>