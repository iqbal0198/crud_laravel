<?php $__env->startSection('content'); ?>
<h3><?php echo e($travel->title); ?></h3>

<p> Atas Nama : <?php echo e($travel->nama); ?></p>
<p> Tujuan : <?php echo e($travel->kota); ?></p>
<p> Harga Tiket : <?php echo e($travel->harga_tiket); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-travel/resources/views/travels/show.blade.php ENDPATH**/ ?>